﻿# Flush PDB
'Flush PDB'
Get-ChildItem -Path C:\1\DevConsole -Recurse | ? { $_.Name -like '*pdb' } | % { Remove-Item -Force $_.FullName }

# Prepare payload
$nuGetPackageVersion = $OctopusParameters["Octopus.Action.Package.NuGetPackageVersion"]
$packageName = "BitTitan.DevConsole.$nuGetPackageVersion"
"Packing $packageName.zip"
Remove-Item -Path C:\1\payload -Recurse -Force -Verbose -ErrorAction SilentlyContinue
New-Item -ItemType Directory C:\1\payload -Force -Verbose
Add-Type -assembly 'system.io.compression.filesystem'
[io.compression.zipfile]::CreateFromDirectory("C:\1\DevConsole", "C:\1\payload\$packageName.zip")
[io.compression.zipfile]::CreateFromDirectory("C:\1\payload", "C:\1\DevConsole\payload.zip")

# Deploy to btchangelog.scm.azurewebsites.net
"Uploading $packageName.zip"
$username = "$($OctopusParameters['Azure.DeploymentCredentials.Username'])"
$password = "$($OctopusParameters['Azure.DeploymentCredentials.Password'])"
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username, $password)))
$userAgent = "powershell/1.0"
$payLoad = "C:\1\DevConsole\payload.zip"
$apiUrl = "https://btdevconsole.scm.azurewebsites.net/api/zipdeploy"
Invoke-RestMethod -Uri $apiUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -UserAgent $userAgent -Method POST -InFile $payLoad -ContentType "multipart/form-data"
'Done'